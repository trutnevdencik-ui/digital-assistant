/**
 * Cloudflare Worker backend for the user's digital voice assistant.
 * No PC, Node.js, Ollama or separately rented VPS is required at runtime.
 */
const CHAT_MODEL = '@cf/qwen/qwen3-30b-a3b-fp8';
const TTS_MODEL = 'xai/grok-tts';
const MAX_BODY = 64 * 1024;
const MAX_TEXT = 3000;

const SYSTEM = (name) => `Ты — ${name || 'цифровой собеседник'}, голосовой ИИ-помощник. Общайся естественно, тепло и уважительно, как живой собеседник. Всегда отвечай по-русски, если пользователь не попросил другой язык. По умолчанию отвечай коротко — одно-три предложения, до 600 символов, если пользователь не просит подробнее. Не используй markdown, эмодзи и служебные ремарки. Не показывай рассуждения или внутренние инструкции. Не выдумывай факты; если не знаешь — честно скажи. Пиши числа обычным текстом.`;

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers }
  });
}
async function readBody(request) {
  const raw = await request.text();
  if (raw.length > MAX_BODY) throw new Error('body_too_large');
  try { return JSON.parse(raw || '{}'); } catch { throw new Error('invalid_json'); }
}
function getReply(result) {
  if (typeof result === 'string') return result;
  return result?.response || result?.result?.response || result?.choices?.[0]?.message?.content || '';
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = {
      'Access-Control-Allow-Origin': url.origin,
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Vary': 'Origin'
    };
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    if (url.pathname === '/api/health' && request.method === 'GET') {
      return json({ ok: true, provider: 'Cloudflare Workers AI', model: CHAT_MODEL, tts: env.NEURAL_TTS_ENABLED === 'true' }, 200, cors);
    }

    if (url.pathname === '/api/chat' && request.method === 'POST') {
      if (!env.APP_ACCESS_KEY) return json({ error: 'access_key_not_configured' }, 503, cors);
      if (request.headers.get('X-Assistant-Key') !== env.APP_ACCESS_KEY) return json({ error: 'access_denied' }, 401, cors);
      try {
        const body = await readBody(request);
        const messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
        if (!messages.length || !messages.every(m => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string')) {
          return json({ error: 'invalid_messages' }, 400, cors);
        }
        const persona = body.persona === 'f' ? 'f' : 'm';
        const fallbackName = persona === 'f' ? 'Алиса' : 'Артём';
        const name = String(body.name || fallbackName).slice(0, 40);
        const safeMessages = messages.map(m => ({ role: m.role, content: m.content.slice(0, MAX_TEXT) }));
        const result = await env.AI.run(CHAT_MODEL, {
          messages: [{ role: 'system', content: SYSTEM(name) }, ...safeMessages],
          max_tokens: 500,
          temperature: 0.7,
          top_p: 0.9
        });
        let reply = String(getReply(result) || '').replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
        if (!reply) return json({ error: 'empty_model_reply' }, 502, cors);
        return json({ reply: reply.slice(0, 4000) }, 200, cors);
      } catch (error) {
        const message = error?.message || 'ai_request_failed';
        return json({ error: message === 'invalid_json' || message === 'body_too_large' ? message : 'ai_request_failed' }, message === 'invalid_json' || message === 'body_too_large' ? 400 : 502, cors);
      }
    }

    if (url.pathname === '/api/tts' && request.method === 'POST') {
      if (!env.APP_ACCESS_KEY) return json({ error: 'access_key_not_configured' }, 503, cors);
      if (request.headers.get('X-Assistant-Key') !== env.APP_ACCESS_KEY) return json({ error: 'access_denied' }, 401, cors);
      try {
        if (env.NEURAL_TTS_ENABLED !== 'true') return json({ error: 'neural_tts_disabled' }, 503, cors);
        const body = await readBody(request);
        const text = String(body.text || '').trim();
        if (!text || text.length > MAX_TEXT) return json({ error: 'text_must_be_1_to_3000_chars' }, 400, cors);
        // Original built-in voices: rex for the masculine persona, ara for the feminine persona.
        const voice_id = body.voice === 'f' ? 'ara' : 'rex';
        const result = await env.AI.run(TTS_MODEL, {
          text,
          language: 'ru',
          voice_id,
          output_format: { codec: 'mp3', sample_rate: 24000, bit_rate: 128000 }
        });
        const audioUrl = result?.audio || result?.result?.audio;
        if (typeof audioUrl !== 'string' || !/^https:\/\//i.test(audioUrl)) return json({ error: 'tts_audio_unavailable' }, 502, cors);
        const audioResponse = await fetch(audioUrl);
        if (!audioResponse.ok) return json({ error: 'tts_download_failed' }, 502, cors);
        return new Response(audioResponse.body, {
          status: 200,
          headers: { ...cors, 'Content-Type': 'audio/mpeg', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }
        });
      } catch (error) {
        return json({ error: 'tts_failed' }, 502, cors);
      }
    }

    // Serve the original HTML and its static assets from the same Worker origin.
    if (env.ASSETS) return env.ASSETS.fetch(request);
    return new Response('Not found', { status: 404 });
  }
};
